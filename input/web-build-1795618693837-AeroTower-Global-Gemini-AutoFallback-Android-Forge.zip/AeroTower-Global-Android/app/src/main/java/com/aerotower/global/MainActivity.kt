package com.aerotower.global

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var pendingRequest: PermissionRequest? = null
    private val microphoneRequestCode = 4102
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val running = AtomicBoolean(false)
    @Volatile private var socket: Socket? = null
    private val prefs by lazy { getSharedPreferences("aerotower_private", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.addJavascriptInterface(AeroBridge(), "AeroBridge")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (!request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { request.deny(); return@runOnUiThread }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    else { pendingRequest = request; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), microphoneRequestCode) }
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun beginNativeSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { webView.evaluateJavascript("window.onSpeechError && window.onSpeechError('Speech recognition service is unavailable on this device')", null); return }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { webView.evaluateJavascript("window.onSpeechStatus && window.onSpeechStatus('Listening…')", null) }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { webView.evaluateJavascript("window.onSpeechStatus && window.onSpeechStatus('Processing speech…')", null) }
                    override fun onError(error: Int) { webView.evaluateJavascript("window.onSpeechError && window.onSpeechError('Speech recognition error $error')", null) }
                    override fun onResults(results: Bundle?) {
                        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        webView.evaluateJavascript("window.onSpeechResult && window.onSpeechResult(${JSONObject.quote(spoken)})", null)
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to AeroTower ATC")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                recognizer.startListening(intent)
            }
        } catch (e: Exception) { webView.evaluateJavascript("window.onSpeechError && window.onSpeechError(${JSONObject.quote(e.message ?: "Unable to start speech recognition")})", null) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.UK
    }

    inner class AeroBridge {
        @JavascriptInterface fun saveApiKey(key: String) {
            val cleaned = key.trim()
            if (cleaned.length < 20) { post("onKeySaved", false); return }
            // Stored only in this app's private sandbox; never returned to JavaScript or logged.
            prefs.edit().putString("gemini_api_key", cleaned).remove("gemini_interaction_id").apply()
            post("onKeySaved", true)
        }
        @JavascriptInterface fun hasApiKey(): Boolean = !prefs.getString("gemini_api_key", null).isNullOrBlank()
        @JavascriptInterface fun clearApiKey() { prefs.edit().remove("gemini_api_key").remove("gemini_interaction_id").apply(); post("onKeyCleared", true) }
        @JavascriptInterface fun speak(text: String) {
            runOnUiThread { if (text.isNotBlank()) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aerotower-atc") }
        }
        @JavascriptInterface fun stopSpeaking() { runOnUiThread { tts?.stop() } }
        @JavascriptInterface fun startNativeSpeech() {
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 4103)
                } else beginNativeSpeech()
            }
        }
        @JavascriptInterface fun stopNativeSpeech() { runOnUiThread { speechRecognizer?.cancel(); post("onSpeechStopped", true) } }

        @JavascriptInterface fun askGemini(prompt: String, contextJson: String) {
            val key = prefs.getString("gemini_api_key", null)
            if (key.isNullOrBlank()) { post("onGeminiError", "Add your Gemini API key in AI SETTINGS first."); return }
            Thread {
                try {
                    val system = """You are AeroTower, a realistic but friendly virtual air traffic control assistant for a FLIGHT SIMULATOR, not real aviation. Speak concise, natural radio phraseology in clear English. Address the pilot by callsign when provided. Ask for missing information rather than inventing it. Use the supplied flight strip and simulator telemetry as context, but if telemetry is absent say so. Never claim a real-world clearance or that you control the simulator. For emergencies, prioritize calm, appropriate simulated ATC communication. Keep replies brief enough to be spoken aloud. Do not invent runway, weather, QNH, taxiway, traffic, or route facts; label illustrative instructions as simulated and ask the pilot to confirm airport/runway details when unknown."""
                    val context = try {
                        val history = JSONArray(contextJson)
                        val transcript = StringBuilder()
                        val from = (history.length() - 8).coerceAtLeast(0)
                        for (i in from until history.length()) {
                            val item = history.optJSONObject(i) ?: continue
                            val role = item.optString("role", "user").uppercase()
                            val parts = item.optJSONArray("parts")
                            val text = parts?.optJSONObject(0)?.optString("text", "").orEmpty()
                            if (text.isNotBlank()) transcript.append(role).append(": ").append(text).append("\n")
                        }
                        transcript.toString()
                    } catch (_: Exception) { "" }
                    val fullInput = buildString {
                        append("SYSTEM INSTRUCTIONS: ").append(system).append("\n\n")
                        if (context.isNotBlank()) append("RECENT RADIO CONTEXT:\n").append(context).append("\n")
                        append("LATEST PILOT TRANSMISSION AND CURRENT FLIGHT CONTEXT:\n").append(prompt)
                    }

                    // Keep 3.8 as the preferred model. If it is overloaded, retry briefly,
                    // then move to the documented 3.7 and 3.6 Flash fallback models.
                    val modelPlan = listOf("gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.6-flash")
                    var successfulRoot: JSONObject? = null
                    var successfulModel = ""
                    var lastCode = 0
                    var lastMessage = ""
                    val savedId = prefs.getString("gemini_interaction_id", null)
                    val savedModel = prefs.getString("gemini_interaction_model", "gemini-3.8-flash")

                    for ((modelIndex, model) in modelPlan.withIndex()) {
                        val retries = if (modelIndex == 0) 2 else 0
                        for (attempt in 0..retries) {
                            if (attempt > 0) Thread.sleep(1000L shl (attempt - 1)) // 1s, then 2s
                            val previousId = if (savedModel == model) savedId else null
                            val result = postInteraction(key, model, fullInput, previousId)
                            lastCode = result.first
                            val response = result.second
                            if (lastCode in 200..299) {
                                successfulRoot = JSONObject(response)
                                successfulModel = model
                                break
                            }
                            lastMessage = try {
                                JSONObject(response).optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
                                    ?: "HTTP $lastCode"
                            } catch (_: Exception) { "HTTP $lastCode" }

                            // If a stored conversation expired, clear it and retry this model fresh.
                            if (lastCode == 400 && !savedId.isNullOrBlank() && savedModel == model && attempt == 0) {
                                prefs.edit().remove("gemini_interaction_id").remove("gemini_interaction_model").apply()
                                val fresh = postInteraction(key, model, fullInput, null)
                                lastCode = fresh.first
                                if (lastCode in 200..299) {
                                    successfulRoot = JSONObject(fresh.second)
                                    successfulModel = model
                                    break
                                }
                                lastMessage = try { JSONObject(fresh.second).optJSONObject("error")?.optString("message") ?: "HTTP $lastCode" } catch (_: Exception) { "HTTP $lastCode" }
                            }

                            // Only overload/server errors trigger a model fallback. Auth, key,
                            // permission and malformed-request errors should be shown directly.
                            if (lastCode != 503 && lastCode != 500 && lastCode != 502 && lastCode != 504) break
                        }
                        if (successfulRoot != null) break
                        if (lastCode != 503 && lastCode != 500 && lastCode != 502 && lastCode != 504) break
                    }

                    val root = successfulRoot
                    if (root == null) {
                        val fallbackHint = if (lastCode == 503 || lastCode == 500 || lastCode == 502 || lastCode == 504)
                            " Google AI is busy. Please try again shortly; AeroTower will retry automatically on your next transmission."
                        else ""
                        post("onGeminiError", "Gemini Interactions API error ($lastCode): $lastMessage.$fallbackHint")
                        return@Thread
                    }

                    val id = root.optString("id", "")
                    if (id.isNotBlank()) prefs.edit()
                        .putString("gemini_interaction_id", id)
                        .putString("gemini_interaction_model", successfulModel)
                        .apply()
                    val answer = extractInteractionText(root)
                    if (answer.isBlank()) post("onGeminiError", "Gemini returned an empty reply. Try again.")
                    else {
                        if (successfulModel != "gemini-3.8-flash") post("onGeminiStatus", "Gemini 3.8 is busy; connected using $successfulModel.")
                        post("onGeminiReply", answer)
                    }
                } catch (e: Exception) {
                    post("onGeminiError", "Connection problem: ${e.message ?: e.javaClass.simpleName}")
                }
            }.start()
        }

        private fun postInteraction(key: String, model: String, input: String, previousId: String?): Pair<Int, String> {
            val body = JSONObject().put("model", model).put("input", input)
            if (!previousId.isNullOrBlank()) body.put("previous_interaction_id", previousId)
            val conn = (URL("https://generativelanguage.googleapis.com/v1beta/interactions").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20000
                readTimeout = 45000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", key)
            }
            return try {
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                Pair(code, response)
            } finally { conn.disconnect() }
        }

        private fun extractInteractionText(root: JSONObject): String {
            val outputText = root.optString("output_text", "").trim()
            if (outputText.isNotBlank() && outputText != "null") return outputText
            val steps = root.optJSONArray("steps") ?: return ""
            val answer = StringBuilder()
            for (i in 0 until steps.length()) {
                val step = steps.optJSONObject(i) ?: continue
                if (step.optString("type") != "model_output") continue
                val content = step.optJSONArray("content") ?: continue
                for (j in 0 until content.length()) {
                    val part = content.optJSONObject(j) ?: continue
                    if (part.optString("type") == "text") answer.append(part.optString("text", ""))
                }
            }
            return answer.toString().trim()
        }

        @JavascriptInterface fun connect(host: String, port: Int) {
            disconnect()
            running.set(true)
            Thread {
                try {
                    val s = Socket(); socket = s; s.connect(InetSocketAddress(host.trim(), port), 5000)
                    post("onTelemetryStatus", "CONNECTED to $host:$port — waiting for flight data")
                    val input = s.getInputStream(); val buffer = ByteArray(8192); val pending = StringBuilder()
                    while (running.get()) {
                        val n = input.read(buffer); if (n < 0) break
                        pending.append(String(buffer, 0, n, Charsets.UTF_8))
                        var newline = pending.indexOf("\n")
                        while (newline >= 0) { val line = pending.substring(0, newline).trim(); if (line.isNotEmpty()) post("onTelemetryData", line); pending.delete(0, newline + 1); newline = pending.indexOf("\n") }
                        if (pending.length >= 2048) { post("onTelemetryData", pending.toString().trim()); pending.setLength(0) }
                    }
                    if (pending.isNotBlank()) post("onTelemetryData", pending.toString().trim())
                    post("onTelemetryStatus", "Telemetry connection closed")
                } catch (e: Exception) { post("onTelemetryStatus", "CONNECTION FAILED: ${e.message ?: e.javaClass.simpleName}") }
                finally { running.set(false); try { socket?.close() } catch (_: Exception) {}; socket = null }
            }.start()
        }
        @JavascriptInterface fun disconnect() { running.set(false); try { socket?.close() } catch (_: Exception) {}; socket = null; post("onTelemetryStatus", "Disconnected") }
        private fun post(fn: String, value: String) { runOnUiThread { webView.evaluateJavascript("window.$fn && window.$fn(${JSONObject.quote(value)})", null) } }
        private fun post(fn: String, value: Boolean) { runOnUiThread { webView.evaluateJavascript("window.$fn && window.$fn($value)", null) } }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == microphoneRequestCode) {
            val request = pendingRequest
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) { request?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)); Toast.makeText(this, "Microphone permission granted", Toast.LENGTH_SHORT).show() }
            else { request?.deny(); Toast.makeText(this, "Microphone unavailable; text radio remains available", Toast.LENGTH_LONG).show() }
            pendingRequest = null
        } else if (requestCode == 4103) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) beginNativeSpeech()
            else webView.evaluateJavascript("window.onSpeechError && window.onSpeechError('Microphone permission denied')", null)
        }
    }
    override fun onDestroy() { try { socket?.close() } catch (_: Exception) {}; running.set(false); tts?.stop(); tts?.shutdown(); speechRecognizer?.destroy(); webView.destroy(); super.onDestroy() }
}
