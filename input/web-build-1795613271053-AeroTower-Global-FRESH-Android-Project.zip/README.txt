AeroTower Global Android project

This is an Android WebView wrapper around the included AeroTower interface.
It requests Android microphone permission when the web interface requests audio capture.

Important limitations:
- This project does not yet establish verified live Aerofly FS Global telemetry.
- The included interface may need further integration and device testing.
- A successful APK build does not by itself prove microphone capture or Aerofly tracking works.
