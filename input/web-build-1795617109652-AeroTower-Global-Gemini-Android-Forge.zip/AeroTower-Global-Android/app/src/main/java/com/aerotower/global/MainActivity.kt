package com.aerotower.global

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var pendingRequest: PermissionRequest? = null
    private val microphoneRequestCode = 4102
    private lateinit var webView: WebView
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val running = AtomicBoolean(false)
    @Volatile private var socket: Socket? = null
    private val prefs by lazy { getSharedPreferences("aerotower_private", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.addJavascriptInterface(AeroBridge(), "AeroBridge")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (!request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { request.deny(); return@runOnUiThread }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    else { pendingRequest = request; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), microphoneRequestCode) }
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun beginNativeSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { webView.evaluateJavascript("window.onSpeechError && window.onSpeechError('Speech recognition service is unavailable on this device')", null); return }
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { webView.evaluateJavascript("window.onSpeechStatus && window.onSpeechStatus('Listening…')", null) }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { webView.evaluateJavascript("window.onSpeechStatus && window.onSpeechStatus('Processing speech…')", null) }
                    override fun onError(error: Int) { webView.evaluateJavascript("window.onSpeechError && window.onSpeechError('Speech recognition error $error')", null) }
                    override fun onResults(results: Bundle?) {
                        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        webView.evaluateJavascript("window.onSpeechResult && window.onSpeechResult(${JSONObject.quote(spoken)})", null)
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to AeroTower ATC")
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                recognizer.startListening(intent)
            }
        } catch (e: Exception) { webView.evaluateJavascript("window.onSpeechError && window.onSpeechError(${JSONObject.quote(e.message ?: "Unable to start speech recognition")})", null) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.UK
    }

    inner class AeroBridge {
        @JavascriptInterface fun saveApiKey(key: String) {
            val cleaned = key.trim()
            if (cleaned.length < 20) { post("onKeySaved", false); return }
            // Stored only in this app's private sandbox; never returned to JavaScript or logged.
            prefs.edit().putString("gemini_api_key", cleaned).apply()
            post("onKeySaved", true)
        }
        @JavascriptInterface fun hasApiKey(): Boolean = !prefs.getString("gemini_api_key", null).isNullOrBlank()
        @JavascriptInterface fun clearApiKey() { prefs.edit().remove("gemini_api_key").apply(); post("onKeyCleared", true) }
        @JavascriptInterface fun speak(text: String) {
            runOnUiThread { if (text.isNotBlank()) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aerotower-atc") }
        }
        @JavascriptInterface fun stopSpeaking() { runOnUiThread { tts?.stop() } }
        @JavascriptInterface fun startNativeSpeech() {
            runOnUiThread {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 4103)
                } else beginNativeSpeech()
            }
        }
        @JavascriptInterface fun stopNativeSpeech() { runOnUiThread { speechRecognizer?.cancel(); post("onSpeechStopped", true) } }

        @JavascriptInterface fun askGemini(prompt: String, contextJson: String) {
            val key = prefs.getString("gemini_api_key", null)
            if (key.isNullOrBlank()) { post("onGeminiError", "Add your Gemini API key in AI SETTINGS first."); return }
            Thread {
                var conn: HttpURLConnection? = null
                try {
                    val history = try { JSONArray(contextJson) } catch (_: Exception) { JSONArray() }
                    val contents = JSONArray()
                    val start = (history.length() - 12).coerceAtLeast(0)
                    for (i in start until history.length()) contents.put(history.getJSONObject(i))
                    val userTurn = JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                    contents.put(userTurn)
                    val system = """You are AeroTower, a realistic but friendly virtual air traffic control assistant for a FLIGHT SIMULATOR, not real aviation. Speak concise, natural radio phraseology in clear English. Address the pilot by callsign when provided. Ask for missing information rather than inventing it. Use the supplied flight strip and simulator telemetry as context, but if telemetry is absent say so. Never claim a real-world clearance or that you control the simulator. For emergency scenarios, prioritize calm, appropriate simulated ATC communication. Keep replies brief enough to be spoken aloud. Do not invent runway, weather, QNH, taxiway, traffic, or route facts; label illustrative instructions as simulated and ask the pilot to confirm airport/runway details when unknown."""
                    val body = JSONObject()
                        .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                        .put("contents", contents)
                        .put("generationConfig", JSONObject().put("temperature", 0.65).put("maxOutputTokens", 220))
                    conn = (URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 15000; readTimeout = 35000; doOutput = true
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("x-goog-api-key", key)
                    }
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val response = stream.bufferedReader().use { it.readText() }
                    if (code !in 200..299) {
                        val message = try { JSONObject(response).optJSONObject("error")?.optString("message") ?: "HTTP $code" } catch (_: Exception) { "HTTP $code" }
                        post("onGeminiError", "Gemini error ($code): $message")
                    } else {
                        val root = JSONObject(response)
                        val parts = root.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                        val answer = buildString { if (parts != null) for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text", "") ?: "") }.trim()
                        if (answer.isBlank()) post("onGeminiError", "Gemini returned an empty reply. Try again.") else post("onGeminiReply", answer)
                    }
                } catch (e: Exception) {
                    post("onGeminiError", "Connection problem: ${e.message ?: e.javaClass.simpleName}")
                } finally { conn?.disconnect() }
            }.start()
        }

        @JavascriptInterface fun connect(host: String, port: Int) {
            disconnect()
            running.set(true)
            Thread {
                try {
                    val s = Socket(); socket = s; s.connect(InetSocketAddress(host.trim(), port), 5000)
                    post("onTelemetryStatus", "CONNECTED to $host:$port — waiting for flight data")
                    val input = s.getInputStream(); val buffer = ByteArray(8192); val pending = StringBuilder()
                    while (running.get()) {
                        val n = input.read(buffer); if (n < 0) break
                        pending.append(String(buffer, 0, n, Charsets.UTF_8))
                        var newline = pending.indexOf("\n")
                        while (newline >= 0) { val line = pending.substring(0, newline).trim(); if (line.isNotEmpty()) post("onTelemetryData", line); pending.delete(0, newline + 1); newline = pending.indexOf("\n") }
                        if (pending.length >= 2048) { post("onTelemetryData", pending.toString().trim()); pending.setLength(0) }
                    }
                    if (pending.isNotBlank()) post("onTelemetryData", pending.toString().trim())
                    post("onTelemetryStatus", "Telemetry connection closed")
                } catch (e: Exception) { post("onTelemetryStatus", "CONNECTION FAILED: ${e.message ?: e.javaClass.simpleName}") }
                finally { running.set(false); try { socket?.close() } catch (_: Exception) {}; socket = null }
            }.start()
        }
        @JavascriptInterface fun disconnect() { running.set(false); try { socket?.close() } catch (_: Exception) {}; socket = null; post("onTelemetryStatus", "Disconnected") }
        private fun post(fn: String, value: String) { runOnUiThread { webView.evaluateJavascript("window.$fn && window.$fn(${JSONObject.quote(value)})", null) } }
        private fun post(fn: String, value: Boolean) { runOnUiThread { webView.evaluateJavascript("window.$fn && window.$fn($value)", null) } }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == microphoneRequestCode) {
            val request = pendingRequest
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) { request?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)); Toast.makeText(this, "Microphone permission granted", Toast.LENGTH_SHORT).show() }
            else { request?.deny(); Toast.makeText(this, "Microphone unavailable; text radio remains available", Toast.LENGTH_LONG).show() }
            pendingRequest = null
        } else if (requestCode == 4103) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) beginNativeSpeech()
            else webView.evaluateJavascript("window.onSpeechError && window.onSpeechError('Microphone permission denied')", null)
        }
    }
    override fun onDestroy() { try { socket?.close() } catch (_: Exception) {}; running.set(false); tts?.stop(); tts?.shutdown(); speechRecognizer?.destroy(); webView.destroy(); super.onDestroy() }
}
