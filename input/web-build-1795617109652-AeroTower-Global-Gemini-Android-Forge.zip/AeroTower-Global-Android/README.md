# AeroTower Global — Android Forge project (Gemini AI build)

This project upgrades the earlier scripted ATC demo with a real Google Gemini text-generation connection and native Android speech output/input.

## What is included

- Gemini API integration using the Google Generative Language REST `generateContent` endpoint (`gemini-2.5-flash`).
- In-app **AI Controller Settings** screen to paste, save, or remove your own Gemini API key.
- API key stored in app-private SharedPreferences; it is not sent back into the WebView or written to logs. It is not a server-side secret vault; use your own key and do not share the APK with the key configured.
- Native Android Text-to-Speech for ATC replies.
- Native Android speech recognition for pilot transmissions (requires microphone permission and an installed speech-recognition service).
- Flight-strip details and any telemetry values currently recognized by the app are sent as context with each AI request.
- Existing TCP telemetry connection scaffold retained.

## Build

Import this folder/project into Android Forge and build the APK. Android Forge should use JDK 17, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35.

## First launch

1. Install and open AeroTower Global.
2. Open **AI Controller Settings**.
3. Create a Gemini API key in Google AI Studio: https://aistudio.google.com/app/apikey
4. Paste the key into the app and tap **SAVE API KEY**. Do not send the key to anyone.
5. Confirm the status says Gemini API key saved / AI controller ready.
6. Use **REQUEST CLEARANCE**, **REQUEST TAXI**, **READY FOR DEPARTURE**, or the microphone / text radio.

The app requires internet access for Gemini. API availability, quotas, billing, model access, and terms are controlled by Google. The current request uses `gemini-2.5-flash` and Google's `x-goog-api-key` header.

## Important limitations and safety

- This is an ATC companion for flight simulation only, not real-world air traffic control. Never use its output for actual flight operations.
- Gemini output is generated, not validated operational clearance. The app explicitly instructs the model not to invent runway, weather, QNH, taxiway, or traffic facts.
- The TCP telemetry socket and parser are retained from the supplied project. A successful Android build does **not** prove that Aerofly FS Global exposes data at the configured host/port or that its wire format matches the parser. Verify live data on the target phone/simulator before relying on telemetry context.
- The Gemini API key is kept in this app's private local storage and is not encrypted by a dedicated keystore layer. It is excluded from Android app backup. Avoid sharing a configured device or APK; remove the key in settings if needed.
- Speech recognition availability depends on Android's installed recognition service and microphone permission. Text radio remains available as a fallback.
