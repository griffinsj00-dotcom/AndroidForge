# AeroTower Global — Android Forge project (Gemini 3.8 Flash)

This project uses Google's Gemini Interactions API with `models/gemini-3.8-flash` for conversational simulated ATC.

## Included
- Gemini Interactions REST endpoint: `https://generativelanguage.googleapis.com/v1beta/interactions`.
- Model: `gemini-3.8-flash`.
- Stateful conversation continuation with `previous_interaction_id`; stale conversations are reset and retried fresh.
- Automatic overload handling: Gemini 3.8 Flash is tried first with two exponential-backoff retries (1s, 2s), then the app falls back to Gemini 3.7 Flash and Gemini 3.6 Flash for temporary 5xx server overloads.
- The app reports when a fallback model is serving the conversation; non-overload errors (such as invalid API keys or access restrictions) are shown instead of being hidden.
- In-app Gemini API-key settings; key is stored in app-private SharedPreferences and never sent to the WebView or written to logs.
- Native Android Text-to-Speech for ATC replies.
- Native Android speech recognition for pilot transmissions.
- Flight-strip details and currently recognized telemetry are sent as context with each AI request.
- Existing TCP telemetry connection scaffold retained.

## Build and setup
1. Import this project into Android Forge and build the APK (JDK 17, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35).
2. Install and open AeroTower Global.
3. Create a Gemini API key in Google AI Studio: https://aistudio.google.com/app/apikey
4. Paste it into **AI Controller Settings** and tap **SAVE API KEY**.
5. Confirm the app reports that the key is saved, then use the radio controls.

## Important limitations
- Google API availability, quotas, billing, model access and terms are controlled by Google. The app requires internet access.
- This is a flight-simulation companion, not real-world air traffic control. Never use its output for actual flight operations.
- Gemini output is generated and is not validated operational clearance. The system prompt tells the model not to invent runway, weather, QNH, taxiway, traffic or route facts.
- The Aerofly TCP socket/parser is retained as scaffolding. A successful build does not prove Aerofly FS Global exposes data at the configured host/port or that the packet format is compatible. Verify actual packets on the phone.
- The API key is stored in app-private storage, not encrypted with a dedicated Android Keystore layer. Avoid sharing a configured device/APK; remove the key in settings when needed.
- Speech recognition depends on Android's installed speech service and microphone permission. Text radio remains available as fallback.


## ATC controller personality upgrade
Every Gemini request now re-supplies a dedicated, non-negotiable ATC-controller identity and radio-behaviour instruction set. Gemini is instructed to remain in controller role on every turn, use concise natural phraseology, maintain a calm and professional personality, handle readbacks, and avoid inventing operational details. Existing native Android speech recognition and text-to-speech paths are unchanged.

The controller remains a flight-simulation companion. It does not provide real-world ATC clearances, and its generated instructions must not be used for actual aviation.
