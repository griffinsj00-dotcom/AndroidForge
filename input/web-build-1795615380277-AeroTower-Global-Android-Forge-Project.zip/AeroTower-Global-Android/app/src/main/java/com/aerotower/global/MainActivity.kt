package com.aerotower.global

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private var pendingRequest: PermissionRequest? = null
    private val microphoneRequestCode = 4102
    private lateinit var webView: WebView
    private val running = AtomicBoolean(false)
    @Volatile private var socket: Socket? = null

    inner class AeroBridge {
        @JavascriptInterface fun connect(host: String, port: Int) {
            disconnect()
            running.set(true)
            Thread {
                try {
                    val s = Socket()
                    socket = s
                    s.connect(InetSocketAddress(host.trim(), port), 5000)
                    s.soTimeout = 0
                    s.getOutputStream().write("GET / HTTP/1.1\r\nHost: $host\r\nConnection: keep-alive\r\n\r\n".toByteArray())
                    post("onTelemetryStatus", "CONNECTED to $host:$port — waiting for flight data")
                    val input = s.getInputStream()
                    val buffer = ByteArray(8192)
                    val pending = StringBuilder()
                    while (running.get()) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        pending.append(String(buffer, 0, n, Charsets.UTF_8))
                        // Aerofly telemetry is a continuous TCP stream. Deliver complete lines,
                        // and also flush bounded chunks for protocols without newline framing.
                        var newline = pending.indexOf("\n")
                        while (newline >= 0) {
                            val line = pending.substring(0, newline).trim()
                            if (line.isNotEmpty()) post("onTelemetryData", line)
                            pending.delete(0, newline + 1)
                            newline = pending.indexOf("\n")
                        }
                        if (pending.length > 0 && pending.length >= 2048) {
                            post("onTelemetryData", pending.toString().trim())
                            pending.setLength(0)
                        }
                    }
                    if (pending.isNotBlank()) post("onTelemetryData", pending.toString().trim())
                    post("onTelemetryStatus", "Telemetry connection closed")
                } catch (e: Exception) {
                    post("onTelemetryStatus", "CONNECTION FAILED: ${e.message ?: e.javaClass.simpleName}")
                } finally {
                    running.set(false)
                    try { socket?.close() } catch (_: Exception) {}
                    socket = null
                }
            }.start()
        }
        @JavascriptInterface fun disconnect() {
            running.set(false)
            try { socket?.close() } catch (_: Exception) {}
            socket = null
            post("onTelemetryStatus", "Disconnected")
        }
        private fun post(fn: String, value: String) {
            runOnUiThread {
                val safe = JSONObject.quote(value)
                webView.evaluateJavascript("window.$fn && window.$fn($safe)", null)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.addJavascriptInterface(AeroBridge(), "AeroBridge")
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    if (!request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) { request.deny(); return@runOnUiThread }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                    else { pendingRequest = request; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), microphoneRequestCode) }
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == microphoneRequestCode) {
            val request = pendingRequest
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                request?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE)); Toast.makeText(this, "Microphone permission granted", Toast.LENGTH_SHORT).show()
            } else { request?.deny(); Toast.makeText(this, "Microphone unavailable; text radio remains available", Toast.LENGTH_LONG).show() }
            pendingRequest = null
        }
    }
    override fun onDestroy() { try { socket?.close() } catch (_: Exception) {}; running.set(false); webView.destroy(); super.onDestroy() }
}
