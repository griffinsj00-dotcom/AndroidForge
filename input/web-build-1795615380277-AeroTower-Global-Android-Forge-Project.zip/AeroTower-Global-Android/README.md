# AeroTower Global — Android Forge project

This is the complete Android Studio/Android Forge project folder. Import the folder (or ZIP) as an existing Gradle Android project.

## Included
- Android WebView app and microphone permission bridge
- Internet/network permissions
- Read-only Aerofly telemetry TCP client in the Android app
- Telemetry screen for latitude, longitude, altitude, heading, ground speed, vertical speed and raw stream
- Existing local ATC radio interface

## Build
1. Import this project into Android Forge as an existing Android/Gradle project.
2. Allow Gradle sync and install any requested Android SDK components.
3. Build the debug APK.

## Telemetry connection
The telemetry panel defaults to `127.0.0.1:58585`. Start Aerofly FS Global and enable its flight-data/FSWidgets output option if present. Tap **CONNECT LIVE DATA**. If localhost does not connect, use the phone's own Wi-Fi IP address in the host field and retry. The documented Aerofly mobile connection used by community integrations is TCP port `58585` and sends `GET / HTTP/1.1` before reading the stream.

The Aerofly community example documents the port and handshake, but not a stable public field schema. This build therefore shows the raw stream and attempts to extract common JSON/key-value names. A successful TCP connection does not guarantee every displayed field will parse. Confirm actual values during a simulator session. This is a read-only simulator companion, not real-world ATC.

Reference: https://www.aerofly.com/community/forum/index.php?postID=191184&thread/28711-fswidget-for-android-help/
